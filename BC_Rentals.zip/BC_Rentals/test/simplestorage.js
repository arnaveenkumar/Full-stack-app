const smartRentals = artifacts.require("./smartRentals.sol");

contract("smartRentals", accounts => {
  it("It should store the data.", async () => {
    const simpleStorageInstance = await smartRentals.deployed();

    // Set the data
    await simpleStorageInstance.updateUser("data", { from: accounts[0] });

    // Get the stored data
    const storedData = await simpleStorageInstance.viewUser.call();

    assert.equal(storedData, "data", "The data was not stored.");
  });
});
