var smartRentals = artifacts.require("./smartRentals.sol");

module.exports = function(deployer) {
  deployer.deploy(smartRentals);
};
