
  import React, { Component, useState, useEffect } from "react";
  import Simple_Storage_Contract from "./contracts/smartRentals.json";
  import getWeb3 from "./getWeb3";
  import moment from "moment";
  import { useHistory } from "react-router-dom";
  import { ethers } from "ethers";
  import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
  import 'bootstrap/dist/css/bootstrap.min.css';
  import { jsPDF } from "jspdf";
  import Offcanvas from 'react-bootstrap/Offcanvas';

  import { Button, Card, Container, Row, Col, Dropdown, Form, Spinner,Navbar,NavDropdown,NavItem,Nav,Modal,Figure  } from 'react-bootstrap';
  import Carousel from 'react-bootstrap/Carousel';

  import nopost from "./no_post.jpg";
  import person_circle from "./img/person-circle.svg";
  import person_circle2 from "./img/person-circle_2.svg";
  import person_circle3 from "./img/person-circle_3.svg";
  import plus_circle from "./img/plus-circle.svg";
  import building_2 from "./img/building_2.svg";
  import building_1 from "./img/building.svg";
  import geo_2 from "./img/geo-alt_2.svg";
  import geo from "./img/geo-alt.svg";
  import  calender from "./img/calendar-week.svg";
  import pencil from "./img/pencil-square.svg";
  import trash_icon from "./img/trash.svg";
  import download_icon from "./img/download.svg";
  import envelope_icon from "./img/envelope.svg";
  import house_icon from "./img/house-door.svg";
  import badge from "./img/person-badge.svg";
  import text from "./img/journal-text.svg";
  import power_icon from "./img/power.svg";
  import rulers_icon from "./img/rulers.svg";
  import phone from "./img/telephone.svg";
  import phone2 from "./img/telephone2.svg";
  import new_icon from "./icon1.png";
  
  import "./App.css";

  import "bootstrap-icons/font/bootstrap-icons.css";



   import "./App.css";

  function Home(props) {

    const ipfs_Client = require("ipfs-http-client");

const _project_Id = '2GaNzU5cDeQ8SuryJ6XeXlYyRUS'
const _project_Secret = 'e8c2784e8cd623251a957c51402e435a'


const _authorization_data = 'Basic ' + Buffer.from(_project_Id + ':' + _project_Secret).toString('base64');
const MY_LISTINGS = "My Listings";
const OWNER_LISTINGS = "Owner Listings";

 const responce =  ipfs_Client.create({
    host: 'infura-ipfs.io',
    port: 5001,
    protocol: 'https',
    apiPath: '/api/v0',
    headers: {
      authorization: _authorization_data
    }
  })
 
  var CryptoJS = require("crypto-js");

  const history = useHistory();
  const [web_3_responce, setweb3_responce] = useState(null)
  const [accounts, setaccounts] = useState(null)
  const [contract, setcontract] = useState(null)
  const [flag, setflag] = useState(true)
  const [event, setevent] = useState("login")
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);

  const [show4, setShow4] = useState(false);
  const [show5, setShow5] = useState(false);
  const [show6, setShow6] = useState(false);
  const [t_c, sett_c] = useState(false);
  const [loader, setloader] = useState(true);
  const [error, setErrorMessage] = useState();
  const [txs, setTxs] = useState([]);
  const [selleradd, setselleradd] = useState("")
  const [eth, seteth] = useState("")
  const[edit_obj,setedit_obj]=useState("")
  const[delete_obj,setdelete_obj]=useState("")
  const[index,setindex]=useState("")

  const handleClose = () => {setShow1(false)
  sethouse_name("")
  sethouse_type("")
  setcontact_no("")
    sethouse_price("")
    setdescription("")
    setbuiltup_area("")
    setaddress("")
    setimg1("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
    setimg2("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
};

  const handleShow = () => setShow1(true)
  const handleShow_seller = () => setShow2(true)
  const handleClose_seller = () => setShow2(false)
  const handleShow_edit = () => setShow3(true)
  const handleClose_edit = () => setShow3(false)
  const handleClose_profile = () => setShow4(false);
  const handleShow_profile = () => setShow4(true);
  const handleClose_agreement = () => {
    window.location.reload()
  
   }
  const handleShow_agreement = () => setShow5(true);
  const handleShow_delete =()=> setShow6(true);
  const handleClose_delete =()=> setShow6(false);

  const [accountdetails, setaccountdetails] = useState(null)
  const[user_list,setuser_list]=useState([])
  const[post_list,setpost_list]=useState([])
  const[current_user,setcurrent_user]=useState("")
  const[data,setdata]=useState("")
  const[seller_info,setseller_info]=useState("")
  const[property_info,setproperty_info]=useState("")
  const[seller_post_count,setseller_post_count]=useState("")
  const[user_post_count,setuser_post_count]=useState("")

  const[repay_amount,setrepay_amount]=useState("")
  const[house_name,sethouse_name]=useState("")
  const[house_type,sethouse_type]=useState("")
  const[builtup_area,setbuiltup_area]=useState("")
  const[contact_no,setcontact_no]=useState("")
  const[house_price,sethouse_price]=useState("")
  const[description,setdescription]=useState("")
  const[posted_at,setposted_at]=useState(moment().format("LLL"))
  const[bought_time,setbought_time]=useState(moment().format("LLL"))
  const [address,setaddress]=useState("")
  const [hash,sethash]=useState("")
  const imgData = require('./icon1.png');
  const check = require('./check.png');
  
  const[owner_details,setowner_details]=useState("")
  const[img1,setimg1]=useState("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
  const[img2,setimg2]=useState("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
  const [file1, setFile1] = useState(null);
  const [file2, setFile2] = useState(null);
  let array=[]
  let count_seller=0
  let count_user=0

    useEffect(() => {
      initilize()

      }, [flag,img1,img2])

       
      let load_data =async(data)=>{

        try{
          let responce =await data.methods.viewUser().call()
          var bytes  = CryptoJS.AES.decrypt(responce, '123');
var originalText = bytes.toString(CryptoJS.enc.Utf8);

        let obj_responce=JSON.parse(originalText)
        array=obj_responce
      
        // console.log(obj_responce);

          setdata(obj_responce)
          setuser_list(obj_responce.user_list)
          setpost_list(obj_responce.post_list)
     
  
            obj_responce.user_list.map((ele)=>{
              if(ele.hash==localStorage.getItem("useraddress")){
              setcurrent_user(ele)
              }
            
            })
            obj_responce.post_list.map((ele)=>{
               if(ele.hash==localStorage.getItem("useraddress")){
                count_user=count_user+1
                
               }
               else{
                count_seller= count_seller+1
  
               }
             })
         
           setseller_post_count(count_seller)
           setuser_post_count(count_user)

           setloader(false)
       
       
         
        }
        catch(err){
  console.log(err);
  setdata([])
        setuser_list([])
        setpost_list([])
        setcurrent_user("")
        setseller_post_count("")
        setuser_post_count("")
        }
      }


      const initilize = (async () => {
      

        try {
       
        const web_3_responce = await getWeb3();
    
        const account_used = await web_3_responce.eth.getAccounts();

        setaccountdetails(account_used)
      
        const net_work_Id = await web_3_responce.eth.net.getId();
       
        const _deployed_Network = Simple_Storage_Contract.networks[net_work_Id];
      
        const instance_data = new web_3_responce.eth.Contract(
          Simple_Storage_Contract.abi,
        _deployed_Network && _deployed_Network.address,
        );
      
        setweb3_responce(instance_data)
        setaccounts(instance_data)
        setcontract(instance_data)

        load_data(instance_data)
    
    
        } catch (message) {
        alert(
        `Cannot fetch web_3_responce.`,
        );
        }
      
        })

        const purchase = async (add,amt) => {
        
        
          setErrorMessage("");
          await startPayment({
            setErrorMessage,
            setTxs,
            ether: amt,
            addr: add
          });
        };


  const startPayment = async ({ setErrorMessage, setTxs, ether, addr }) => {

    try {
    
   
  
      if (!window.ethereum)
        throw new Error("Please install any crypto wallet.");

      await window.ethereum.request({ method: 'eth_requestAccounts' });
      const _responce_provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer_data = _responce_provider.getSigner();
      ethers.utils.getAddress(addr);
      const tx = await signer_data.sendTransaction({
        to: addr,
        value: ethers.utils.parseEther(ether)
      });

      setTxs([tx]);
      await user_update()
      alert("Purchased successfully")
      
    } catch (err) {
      setErrorMessage(err.message);
      window.location.reload()
    }
  };

  let post_function = async(obj)=>{
    post_list.push(obj)
  let data_list={
    "user_list":user_list,
    "post_list":post_list
  }
 

  try{
    JSON.stringify(data_list)
    var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data_list), '123').toString();
    
    
    await contract.methods.updateUser(ciphertext).send({ from: accountdetails[0] })
  

    window.location.reload()
    
  }
    catch{
      handleClose()
      window.location.reload()
    }
}

          
function print_agreement(val) {
  let seller=null
user_list.map((ele)=>{
if(ele.hash==val.hash){
seller=ele
}
})
	
  const doc = jsPDF({
    unit: "mm",
    format: [297, 210]
  })

  doc.addImage(imgData, 'jpg', 165, 18, 26, 26, 'alias');


  doc.setFont("helvetica");
doc.setFontSize(14);
  doc.text(`DATE : ${val.bought_time}`, 10, 26);
doc.setFontSize(20);
  doc.text("RENTAL AGREEMENT", 67, 60);
doc.setFontSize(14);
  doc.text(`Agreement between ${seller.name}, (OWNER), and ${current_user.name}, (TENANT), for a property`, 17, 85);
   doc.text(`located at  ${val.address}.`, 17, 95);
   
     doc.text("Tenant agrees to rent this property on yearly basis for", 40, 110);
doc.text(`${val.house_price} ETH per year. For which Owner will give Tenant the rights to OWN the property`, 17, 120);
doc.text(`from ${val.bought_time} to ${val.period}.`, 17, 130);
doc.setFontSize(18);
doc.text("Property Details :", 22, 156);
doc.setFontSize(14);
doc.text(`Name : ${val.house_name}`, 22, 170);
doc.text(`Price : ${val.house_price} ETH`, 22, 180);
doc.text(`Location : ${val.address}`, 120, 170);
doc.text(`Type : ${val.house_type}`, 120, 180);

doc.setFontSize(18);
doc.text("Tenant Details :", 22, 200);
doc.setFontSize(14);
doc.text(`Name : ${current_user.name}`, 22, 215);
doc.text(`Email : ${current_user.email}`, 22, 225);
doc.text(`Ph No : ${current_user.ph_no}`, 22, 235);

doc.setFontSize(18);
doc.text("Owner Details:", 120, 200);
doc.setFontSize(14);
doc.text(`Name : ${seller.name}`, 120, 215);
doc.text(`Email : ${seller.email}`, 120, 225);
doc.text(`Ph No : ${seller.ph_no}`, 120, 235);

  doc.save(`Agreement.pdf`);
}


let post_update = async(post)=>{
let data_list={
  "user_list":user_list,
  "post_list":post
}

  try{
   
    JSON.stringify(data_list)
    var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data_list), '123').toString();
    
    
    await contract.methods.updateUser(ciphertext).send({ from: accountdetails[0] })
    window.location.reload()
    
  }
  catch{
    handleClose()
    window.location.reload()
  }
}

let user_update = async()=>{
  let data_list={
    "user_list":user_list,
    "post_list":post_list
  }
  
    try{
      JSON.stringify(data_list)
      var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data_list), '123').toString();
      
      
      await contract.methods.updateUser(ciphertext).send({ from: accountdetails[0] })
      window.location.reload()
      
    }
    catch{
      handleClose()
      window.location.reload()
    }
  }

function setting_seller(val,){
  user_list.map((ele)=>{
    if(ele.hash==val){
    setseller_info(ele)
    }
  
  })
} 

function setting_agreement(val){
  handleShow_agreement()

  user_list.map((ele)=>{
    if(ele.hash==val.hash){
    setseller_info(ele)
    }
  
  })
} 



 //*************IPFS part************** */
 const retrieveFile_from_ipfs = (e) => {
  const data1 = e.target.files[0];
  const reader = new window.FileReader();
  reader.readAsArrayBuffer(data1);
  reader.onloadend = () => {
    setFile1(Buffer(reader.result));
  }
  e.preventDefault();  
}
const Submit = async (e) => {
    e.preventDefault();
    try {
      const created = await responce.add(file1);
  
      const url1 = `https://infura-ipfs.io/ipfs/${created.path}`;
      if( show3==true){
        setedit_obj({...edit_obj, img1:url1})  
      }
      else{
        setimg1(url1)
      }
    

    } catch (error) {

      if( show3==true){
        setedit_obj({...edit_obj, img1:"https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff"})  
      }
      else{
        setimg1("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
      }
      console.log(error.message);
      console.log("error");
    }
  };



//*************IPFS part************** */

    //*************IPFS part 2************** */
    const retrieveFile2 = (e) => {
      const data2 = e.target.files[0];
      const reader = new window.FileReader();
      reader.readAsArrayBuffer(data2);
      reader.onloadend = () => {
        setFile2(Buffer(reader.result));
      }
      e.preventDefault();  
    }
    const Submit2 = async (e) => {
        e.preventDefault();
        try {
          const created = await responce.add(file2);
          const url2 = `https://infura-ipfs.io/ipfs/${created.path}`;
          if( show3==true){
            setedit_obj({...edit_obj, img2:url2})  
          }
          else{
            setimg2(url2)
          }

           
        } catch (error) {
          if( show3==true){
            setedit_obj({...edit_obj, img2:"https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff"})  
          }
          else{
            setimg2("https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg?w=740&t=st=1667045999~exp=1667046599~hmac=a23b584e991a2fcea12bb6f73c48b67ecc4cfd3d91c00bca2d525d07495d9fff")
          }
          console.log(error.message);
        }
      };
    
     
    //*************IPFS part 2************** */




  if (loader) {
    return (
      <div style={{marginTop:"20%"}} class="d-flex flex-column  align-items-center">
<div class="">
  <Spinner variant="primary" animation="border" role="status" >
    
       </Spinner>
    </div>
<div class="mt-1" style={{fontWeight:"550",fontFamily:"Helvetica !important"}}><h2>Loading...</h2></div>
</div>
    )



  }
 
  return(
   
    <>
   
    <Container fluid style={{padding:"0%"}}>
    
    <Navbar  expand="lg" style={{backgroundColor:"#005ca8"}}>
        <Container fluid>
        <img
                src={new_icon}
                width="50"
                height="50"
                className="d-inline-block align-top"
                alt="React Bootstrap logo"
                style={{borderRadius:15}}
              />  
              <i class="mt-2" style={{color:"white",fontWeight:"bold"}}>&nbsp;BLOCKCHAIN SMART RENTAL</i>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto">
          
              


            
      <Button variant="link" onClick={handleShow_profile} className="mx-0"><img  src={person_circle}/>
     </Button>
              <Button variant="link" className="mx-0" 
              onClick={()=>{
                localStorage.clear();
                history.push("/login")
                window.location.reload();
              }}
              
              ><img src={power_icon}/></Button>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    
  <div class="jumbotron py-3 mb-3" style={{height:150,backgroundColor:"#005ca8"}}>
    <h6 class="display-6 ml-5" style={{color:"white",marginLeft:20}}>Hello, {current_user.name}!</h6>

  </div>


  <div class="container" style={{width:"70%",marginTop:"-3.75rem"}}>
  <Tabs
      defaultActiveKey= {MY_LISTINGS}
      className="mb-3 tab_tab"
      style={{backgroundColor:"#f0f2f5",borderRadius:50}}
      id="fill-tab-example"
      fill
   
      

      
     

    >
      <Tab eventKey= {MY_LISTINGS} title={MY_LISTINGS}>
        <div style={{display:"flex",justifyContent:"end"}}>
     


      <Button variant="link"
              onClick={()=>{
            if(user_post_count==5){
              alert("No more post can be added")
            }
            else{
              handleShow()
            }
                 
               
              }}
              
              >   <img src={plus_circle}/></Button>
              </div>

{
user_post_count!=0?(
  data.post_list.map((val,i)=>(
    val.hash==localStorage.getItem("useraddress")?(
      <>
      <div class="mt-5 pb-5" style={{borderBottom: "solid", borderWidth:"1px"}}>

      <Row >
        <Col md={4}>
  
         <Carousel fade controls={false} indicators={false} interval={2000} >
            <Carousel.Item>
            
               <Figure class="pt-5 mt-3">
        <Figure.Image
          width={620}
          height={550}
          alt="171x180"
          src={val.img1}
          style={{borderRadius:"8%"}}
          />
      </Figure >
             
            </Carousel.Item>
            <Carousel.Item>
               <Figure class="pt-5 mt-3">
        <Figure.Image
          width={620}
          height={550}
          alt="171x180"
          src={val.img2}
          style={{borderRadius:"8%"}}
          />
      </Figure >
      
             
            </Carousel.Item>
           
          </Carousel>
         
        </Col>
        <Col md={8}>
         
          <div class="d-flex flex-row mb-3 justify-content-around">
          <div class="p-2"><h2>{val.house_name} &nbsp;&nbsp;<Button   onClick={()=>{
                  setedit_obj(val)
                  setindex(i)
                   handleShow_edit()
                 
                }} variant="link">
  <img src={pencil}/>
  </Button>  &nbsp;&nbsp;<Button   onClick={()=>{
                 setdelete_obj(val)
                  setindex(i)
                   handleShow_delete()
                 
                }} variant="link">
 <img src={trash_icon}/>
  </Button> </h2>
 
   
</div>

</div>

<div class="d-flex flex-row mb-3 justify-content-evenly">
  <div class="p-2"> <p> <img src={building_1}/> {val.house_type}</p></div>
<div class="p-2"> <p><img width="28" height="28" src="https://img.icons8.com/color/48/000000/ethereum.png"/> {val.house_price}</p></div>
  <div class="p-2"> <p><img src={geo}/> {val.address}</p></div>

 
</div>

<div class="d-flex flex-row mb-3 justify-content-evenly">
  <div class="p-2"> <p><img src={phone}/> {val.contact_no}</p></div>
<div class="p-2"> <p><img src={calender}/>  {val.posted_at}</p></div>
<div class="p-2"> <p><img src={rulers_icon}/> {val.builtup_area}</p></div>
 

 
</div>





<div class="d-flex flex-row mb-3 justify-content-evenly" style={{marginLeft:25}}>
  <div class="p-2"><p><img src={text}/> {val.description}</p></div>
 
 
</div>
 
        </Col>
        </Row>
      
          </div>
      </>
  
  
    ):(null)
  
  
  ))
):(
  <div style={{display:"flex",justifyContent:"center",paddingBottom:"5%"}}>
 <Figure>
  <Figure.Image
    width={500}
    height={500}
    alt="171x180"
    src={nopost}
    style={{borderRadius:"8%"}}
    />
     <Figure.Caption class="text-center">
       User has not created any listings.
      </Figure.Caption>
</Figure>
  </div>
 
)
}
 </Tab>
      <Tab eventKey={OWNER_LISTINGS} title={OWNER_LISTINGS}>
      {
seller_post_count!=0?(    
post_list.map((val,i)=>(
  val.hash!=localStorage.getItem("useraddress")?(
    <>
    <div class="mt-5 pb-5" style={{borderBottom: "solid", borderWidth:"1px"}}>
    <Row >
    <Col  md={4}>
  
  <Carousel fade controls={false} indicators={false} interval={2000} >
     <Carousel.Item>
     
        <Figure class="pt-5 mt-5">
 <Figure.Image
      width={620}
      height={550}
   alt="171x180"
   src={val.img1}
   style={{borderRadius:"8%"}}
   />
</Figure>
     
     </Carousel.Item>
     <Carousel.Item>
        <Figure class="pt-5 mt-5">
 <Figure.Image
      width={620}
      height={550}
   alt="171x180"
   src={val.img2}
   style={{borderRadius:"8%"}}
   />
</Figure>

       
     </Carousel.Item>
    
   </Carousel>
  
 </Col>
      <Col md={8}>
      <div class="d-flex flex-row mb-3 justify-content-around">
  <div class="p-2"><h2>{val.house_name}  </h2>
 
   
</div>
 
</div>

<div class="d-flex flex-row mb-3 justify-content-evenly">
  <div class="p-2"> <p> <img src={building_1}/>  {val.house_type}</p></div>
<div class="p-2"> <p> <img width="28" height="28" src="https://img.icons8.com/color/48/000000/ethereum.png"/> {val.house_price}</p></div>
  <div class="p-2"> <p><img src={geo}/> {val.address}</p></div>

 
</div>

<div class="d-flex flex-row mb-3 justify-content-evenly">
  <div class="p-2"> <p><img src={phone}/> {val.contact_no}</p></div>
<div class="p-2"> <p><img src={calender}/> {val.posted_at}</p></div>
<div class="p-2"> <p><img src={rulers_icon}/> {val.builtup_area}</p></div>
  

 
</div>





<div class="d-flex flex-row mb-3 justify-content-evenly" style={{marginLeft:25}}>
  <div class="p-2"><p><img src={text}/> {val.description}</p></div>
 
 
</div>

  { 
  
      val.bought_by==localStorage.getItem("useraddress") && moment(new Date()).format("LLL")<val.period ?(
        <h5 class="text-center">This property is not available till {val.period} </h5>
      )
      :(
<>
<div class="text-center">
<Button variant="outline-primary" className="mx-2"
        onClick={()=>{
      setting_seller(val.hash,val)
           handleShow_seller()
         
        }}
        
        ><img src={badge} style={{marginTop:-1}} />&nbsp; CONTACT </Button>

<Button variant="outline-primary" className="mx-2"
        onClick={()=>{
       
      
        val.bought_by=current_user.hash
        val.period=moment(new Date()).add(365, 'days').format("LLL")
        val.bought_time=moment(new Date()).format("LLL")
        
        setproperty_info(val)
          setting_agreement(val)
         
         
        }}
        
        ><img src={house_icon} style={{marginTop:-1}}/> &nbsp;BUY / RENT</Button>
</div>
       
        </>
      )
      }
    
      </Col>
      </Row>
    
        </div>
    </>


  ):(null)


))
):(
  <div style={{display:"flex",justifyContent:"center",paddingBottom:"5%"}}>
 <Figure  >
  <Figure.Image
    width={500}
    height={500}
    alt="171x180"
    src={nopost}
    style={{borderRadius:"8%"}}
    />
     <Figure.Caption class="text-center">
     Owner has not created any listings.
      </Figure.Caption>
</Figure>
  </div>
)
}

      </Tab>
     
      
    </Tabs>

  </div>




  <div >

  <Modal show={show2} onHide={handleClose_seller}  size="sm">
          <Modal.Header closeButton>
            <Modal.Title>Owner Details!</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <br></br>


    
<Row>
 
 <p  style={{marginLeft:8}}> <img src={person_circle3}/> &nbsp;{seller_info.name}</p>
  
  <p  style={{marginLeft:8}}> <img src={phone2}/> &nbsp;&nbsp;&nbsp;{seller_info.ph_no}</p>
 

 <p  style={{marginLeft:8}}><img src={geo_2}/>&nbsp;&nbsp;&nbsp;{seller_info.address}</p>
 
  <p style={{marginLeft:8}}><img src={envelope_icon}/>&nbsp;&nbsp;&nbsp;{seller_info.email}</p>
 
</Row>

          </Modal.Body>
          
        </Modal>

  </div>

  <div >

<Modal show={show6} onHide={handleClose_delete}  style={{marginTop:"9%"}} size="md">
        <Modal.Header closeButton>
          <Modal.Title>Are you sure you want to delete ?</Modal.Title>
        </Modal.Header>
        <Modal.Footer>
        <Button variant="outline-primary" type="submit" onClick={()=>{handleClose_delete()}}>
          NO
        </Button>
        <Button variant="outline-primary" type="submit" onClick={()=>{
             post_list.splice(index, 1);
             post_update(post_list)
             setloader(true)

        }}>
          YES
        </Button>

  


        </Modal.Footer>
        
      </Modal>

</div>



<div >

<Modal show={show1} onHide={handleClose}  size="lg" >
        <Modal.Header closeButton>
          <Modal.Title style={{color:"#005ca8"}}>Welcome!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <br></br>


  
<Row>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Name" value={house_name} onChange={(e)=>{
        sethouse_name(e.target.value)
    
      }}/>
                </Form.Group>
</Col>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Type" value={house_type} onChange={(e)=>{
        sethouse_type(e.target.value)
    
      }}/>
                </Form.Group>
</Col>
</Row>

<Row>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Rent Deposit (In Ethers)" value={house_price} onChange={(e)=>{
        sethouse_price(e.target.value)
    
      }}/>
                </Form.Group>
</Col>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Location" value={address} onChange={(e)=>{
        setaddress(e.target.value)
    
      }}/>
                </Form.Group>
                
</Col>
</Row>

<Row>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Phone number" value={contact_no} onChange={(e)=>{
        setcontact_no(e.target.value)
    
      }}/>
                </Form.Group>
</Col>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Property Size (Sq ft)" value={builtup_area} onChange={(e)=>{
        setbuiltup_area(e.target.value)
    
      }}/>
                </Form.Group>

                
</Col>
</Row>
<Row>


<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Description" value={description} onChange={(e)=>{
        setdescription(e.target.value)
    
      }}/>
                </Form.Group>


</Row>
<Row>
  <Col>
  <form className="form" onSubmit={Submit}>
    <Row>
      <Col md={8}>
      <input class="form-control form-control-sm" id="formFileSm" onChange={retrieveFile_from_ipfs} type="file"/>

      </Col>
      <Col  md={4}>
      <Button variant="outline-primary" type="submit">
          Upload
        </Button>
      </Col>
 
    </Row>
 
</form>
<Figure class="mt-3 text-center">
<Figure.Image
          width={300}
          height={300}
          alt="171x180"
          src={img1}
          style={{borderRadius:"8%"}}
          />
      </Figure>
  </Col>
  <Col>
  <form className="form" onSubmit={Submit2}>
    <Row>
      <Col md={8}>
      <input class="form-control form-control-sm" id="formFileSm" onChange={retrieveFile2} type="file"/>
      </Col>
      <Col md={4}>
      <Button variant="outline-primary" type="submit">
          Upload
        </Button>
      </Col>
    </Row>

</form>
<Figure class="mt-3 text-center">
<Figure.Image
          width={300}
          height={300}
          alt="171x180"
          src={img2}
          style={{borderRadius:"8%"}}
          />
      </Figure>
  </Col>
</Row>

   </Modal.Body>
        <Modal.Footer>
       
        
        <Button variant="outline-primary" onClick={()=>{
          handleClose()
        }
          }>
          Close
        </Button>
    
        <Button variant="outline-primary" onClick={()=>{
             
            let obj= {
                house_name,
                house_type,
                address,
                contact_no,
                posted_at,
                house_price,
                description,
                hash:localStorage.getItem("useraddress"),
                builtup_area,
                img1,
                img2,
                bought_by:null,
                period:null,
                bought_time:null
                

               
              }
          post_function(obj)
          setloader(true)
            }
              }>
              Save
            </Button>
        </Modal.Footer>
      </Modal>

</div>


<div >

<Modal show={show3} onHide={handleClose_edit}  size="lg">
        <Modal.Header closeButton>
          <Modal.Title style={{color:"#005ca8"}}>Welcome!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <br></br>


  
<Row>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Name" value={edit_obj.house_name} onChange={(e)=>{
        setedit_obj({...edit_obj, house_name:e.target.value})

    
      }}/>
                </Form.Group>
</Col>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Type" value={edit_obj.house_type} onChange={(e)=>{
      setedit_obj({...edit_obj, house_type:e.target.value})    
      }}/>
                </Form.Group>
</Col>
</Row>

<Row>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Rent Deposit (In Ethers)" value={edit_obj.house_price} onChange={(e)=>{
      setedit_obj({...edit_obj, house_price:e.target.value})    
      }}/>
                </Form.Group>
</Col>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Location" value={edit_obj.address} onChange={(e)=>{
      setedit_obj({...edit_obj, address:e.target.value})    
      }}/>
                </Form.Group>
                
</Col>
</Row>

<Row>
<Col>

<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Phone number" value={edit_obj.contact_no} onChange={(e)=>{
      setedit_obj({...edit_obj, contact_no:e.target.value})    
      }}/>
                </Form.Group>
</Col>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Property Size (Sq ft)" value={edit_obj.builtup_area} onChange={(e)=>{
      setedit_obj({...edit_obj, builtup_area:e.target.value})    
      }}/>
                </Form.Group>

                
</Col>
</Row>

<Row>
<Col>
<Form.Group className="mb-4" controlId="formBasicPassword">
                  
                  <Form.Control type="text" placeholder="Description" value={edit_obj.description} onChange={(e)=>{
      setedit_obj({...edit_obj, description:e.target.value})    
      }}/>
                </Form.Group>

</Col>

</Row>

<Row>
  <Col>
  <form className="form" onSubmit={Submit}>
    <Row>
      <Col md={8}>
      <input class="form-control form-control-sm" id="formFileSm" onChange={retrieveFile_from_ipfs} type="file"/>

      </Col>
      <Col md={4}>
      <Button variant="outline-primary" type="submit">
          Upload
        </Button>
      </Col>
    </Row>
  
</form>
<Figure class="mt-3 text-center">
<Figure.Image
          width={300}
          height={300}
          alt="171x180"
          src={edit_obj.img1}
          style={{borderRadius:"8%"}}
          />
      </Figure>

    
  </Col>
  <Col>
  <form className="form" onSubmit={Submit2}> <Row>
      <Col md={8}>
      <input class="form-control form-control-sm" id="formFileSm" onChange={retrieveFile2} type="file"/>

      </Col>
      <Col md={4}>
      <Button variant="outline-primary" type="submit">
          Upload
        </Button>
      </Col>
    </Row>
 
</form>
<Figure class="mt-3 text-center">
<Figure.Image
          width={300}
          height={300}
          alt="171x180"
          src={edit_obj.img2}
          style={{borderRadius:"8%"}}
          />
      </Figure>
  </Col>
</Row>

   </Modal.Body>
        <Modal.Footer>
        
          <Button variant="outline-primary" onClick={()=>{
            post_list.splice(index, 1);
            post_list.push(edit_obj)
            post_update(post_list)
            setloader(true)

          }
            }>
            Save
          </Button>
        </Modal.Footer>
      </Modal>

</div>



<div>
<Offcanvas show={show4} onHide={handleClose_profile} placement="end" {...props}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title><h4 class="mt-5"><img src={person_circle2}/> &nbsp;{current_user.name}</h4></Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>   
  
  <div style={{marginLeft:6}}>
  <h5 style={{color:"grey"}}><img src={phone2}/> &nbsp;{current_user.ph_no}</h5>

<h5 style={{color:"grey"}}>  <img src={geo_2}/> &nbsp;&nbsp;{current_user.address}</h5>

 <h5 style={{color:"grey"}}><img src={envelope_icon}/> &nbsp;{current_user.email}</h5>

{
  show4==true?( 
 
    current_user.properties_bought.length>0?(
      <>
       <h5 class="mt-3" style={{marginLeft:0, color:"#005ca8"}}>Properties Purchased</h5>
       {current_user.properties_bought.map((val)=>(
        <>
        <Row>
          <Col md={8}>
          <h5 class="mt-3" style={{color:"grey"}}><img src={building_2}/> &nbsp;{val.house_name}</h5>
          </Col>
          <Col md={4}>
          <Button variant="link"  onClick={()=>print_agreement(val)}> <img src={download_icon}/></Button>
          </Col>
     
         
        </Row>
         
         </>
          ))
       }

      </>
     
    
   ):
   (null)
   
   
  ):(null)
}


 


  </div>
  

        </Offcanvas.Body>
      </Offcanvas>
</div>

<div >

<Modal show={show5} onHide={handleClose_agreement} size="lg" >


        <Modal.Header closeButton >
          <Modal.Title  ><h4 class="aggrement">Rental Agreement!</h4></Modal.Title>
        </Modal.Header>
        <Modal.Body >
          <br></br>




  <div style={{display:"flex", justifyContent:"space-between",marginTop:"-5%"}}>
  <h5  class="aggrement" style={{marginTop:20}}>Date : {posted_at}</h5>
  
  <Figure >
  <Figure.Image
          width={70}
          height={70}
          alt="171x180"
          src="https://img.freepik.com/free-vector/document-signing-partnership-deal-business-consultation-work-arrangement-client-assistant-writing-contract-cartoon-characters_335657-2342.jpg?size=338&ext=jpg&ga=GA1.2.1617070347.1666937313"
          style={{borderRadius:"8%",marginRight:"auto"}}
          />
      </Figure>
  </div>

  <pre>
<h4  class="aggrement" >Agreement between {seller_info.name},(Owner) and {current_user.name} (Tenant),<br></br>
for the property located at {property_info.address} (Location). 
<br></br>
<br></br>
Tenant agrees to purchase/rent this property on 
<br></br>
yearly basis for <img width="28" height="28" src="https://img.icons8.com/color/48/000000/ethereum.png"/> {property_info.house_price} ETH per year.
<br></br>
For which Owner will give Tenant the rights to OWN the 
<br></br>property from {posted_at} <br></br>to {moment(new Date()).add(365, 'days').format("LLL")}.</h4>



</pre>
<Form.Check 
            type="checkbox"
            id="checkbox"
            label="I accept the terms and conditions"
            onChange={()=>{
            sett_c(!t_c)
            }}
          />
   
        </Modal.Body>
        <Modal.Footer>
        <Button variant="outline-primary"  disabled={!t_c} onClick={()=>{

          user_list.map((ele)=>{
            if(ele.hash==localStorage.getItem("useraddress")){
              ele.properties_bought.push(property_info)
          
            }
          
          })
          setuser_list(user_list)
        purchase(seller_info.hash,property_info.house_price)
        setloader(true)
           }}>
           <img width="22" height="22" src="https://img.icons8.com/color/48/000000/ethereum.png"/> Pay &nbsp; 
         </Button>
          <Button variant="outline-primary" onClick={()=>{
         
          handleClose_agreement()
            }}>
            Close
          </Button>
        </Modal.Footer>
       
      </Modal>

</div>

  </Container>

    
    </>
  )

  }

  export default Home;

