
    import React, { Component, useState, useEffect } from "react";
    import SimpleStorageContract from "./contracts/smartRentals.json";
    import getWeb3 from "./getWeb3";

    import 'bootstrap/dist/css/bootstrap.min.css';
    import { Button, Card, Container, Row, Col, Dropdown, Form, Spinner } from 'react-bootstrap';
    import reset from "./img/reset.svg";
   
    import backgroundImage from "./4.jpg";
  
    import "./App.css";
    var CryptoJS = require("crypto-js");

    function Login(props) {

  
        const [loginstate,setloginstate]= useState("login")
        const [web_3_responce, setweb3_responce] = useState(null)
        const [accounts, setaccounts] = useState(null)
        const [contract, setcontract] = useState(null)
        const [flag, setflag] = useState(0)
        const [accountdetails, setaccountdetails] = useState(null)
        const[u_name,setu_name]= useState("")
        const[u_email,setu_email]= useState("")
        const[u_home_address,setu_home_address]= useState("")
        const[u_ph_no,setu_ph_no]= useState("")
        const[u_password,setu_password]= useState("")
        const[u_address,setu_address]=useState("")
        const[user_type1,setuser_type1]=useState(false)
        const[user_type2,setuser_type2]=useState(false)
        const[user_type,setuser_type]=useState("USER")
        const[user_list,setuser_list]=useState([])
        const[post_list,setpost_list]=useState([])
        const[adminexisst,setadminexisst]=useState(false)
        const[loader,setloader]=useState(false)
        const [loading, setloading] = useState(false);

        const [urlArr, setUrlArr] = useState([]);
  const [file, setFile] = useState(null);
  const [user_length, setuser_length] = useState(null);

  const ACCOUNT_ADDRESS = "Account address";
        useEffect(() => {
          initilize()
          }, [flag])


        


          let load_data =async(data)=>{
            try{

              let responce =await data.methods.viewUser().call()
                            // Decrypt
var bytes  = CryptoJS.AES.decrypt(responce, '123');
var originalText = bytes.toString(CryptoJS.enc.Utf8);

              let array=[]
            let obj_responce=JSON.parse(originalText)
            setuser_list(obj_responce.user_list)
            setpost_list(obj_responce.post_list)
            setuser_length(obj_responce.user_list.length)
         
            }
            catch(err){
  console.log(err,"error");
  setuser_list([])
  setpost_list([])
            }
          }

          const initilize = (async () => {
      

            try {
           
            const web_3_responce = await getWeb3();
            console.log(web_3_responce,"web3");
        
            const account_used = await web_3_responce.eth.getAccounts();
    console.log(account_used,"account_used");
            setaccountdetails(account_used)
          
            const net_work_Id = await web_3_responce.eth.net.getId();
           console.log(net_work_Id,"net_work_Id");
            const _deployed_Network = SimpleStorageContract.networks[net_work_Id];
          console.log(_deployed_Network,"_deployed_Network");
            const data_instance = new web_3_responce.eth.Contract(
            SimpleStorageContract.abi,
            _deployed_Network && _deployed_Network.address,
            );
          
            setweb3_responce(data_instance)
            setaccounts(data_instance)
            setcontract(data_instance)
    
            load_data(data_instance)
        
        
            } catch (error) {
            alert(
            `Failed to load web_3_responce, account deployedNetwork && deployedNetwork.address,
            ts, or contract. Check console for details.`,
            );
            console.error(error);
            }
          
            })


  
        

        let login_function = async(username, password)=>{
          try{
            let responce_user =await contract.methods.userAuth(username, password).call()

            
            if(responce_user==1){
        localStorage.setItem("usertype","USER")
        localStorage.setItem("login",responce_user)
        localStorage.setItem("useraddress",username)
      props.history.push("/home")
      window.location.reload()
      }
      else{
        alert("Invalid details")
            window.location.reload()
      }


    
          }catch(err){
            alert("Invalid details")
            window.location.reload()
    console.log(err);
          }
        }

        let reset_function = async()=>{
          try{
            let data_list={
              "user_list":[],
              "post_list":[]
              }
            let reset_res =await contract.methods.updateUser(JSON.stringify(data_list)).send({ from: accountdetails[0] })

            
         
              alert("Reset Successful")
      window.location.reload()
    
   


    
          }catch(err){
            alert("Something went wrong")
            window.location.reload()
    console.log(err);
          }
        }


        let signup_function = async(useraddress,username, password,phone,address,email)=>{
if(user_length!=5)
{
  if(useraddress!="" && username!="" && password!="" && phone!="" && address!="" && email!=""){
    try{
     

        let user_details={
          name:username,
          ph_no:phone,
          email:email,
          hash:useraddress,
          address:address,
          properties_bought:[]
          
         
        
        }

let responce =await contract.methods.userReg(useraddress,username, password).send({ from: accountdetails[0] })
user_list.push(user_details)
let data_list={
"user_list":user_list,
"post_list":post_list
}

// Encrypt
JSON.stringify(data_list)
var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data_list), '123').toString();



let responce2 =await contract.methods.updateUser(ciphertext).send({ from: accountdetails[0] })
alert("Account created successfully")
window.location.reload()


    }catch(err){
      console.log(err);
      alert("Something went wrong")
      window.location.reload()
    }
  }
  else{
    alert("Please fill all fields")
    window.location.reload()
  }
}
else{
  alert("No more accounts can be created")
  window.location.reload()
}
         
         
        

        }

   
   
  if (loading) {
    return (
      <div style={{marginTop:"20%"}} class="d-flex flex-column  align-items-center">
<div class="">
  <Spinner variant="primary" animation="border" role="status" >
    
       </Spinner>
    </div>
<div class="mt-1" style={{fontWeight:"550",fontFamily:"Helvetica !important"}}><h2>Loading...</h2></div>
</div>
    )



  }
    return (
 
    <>
    <div className="auth-wrapper" style={{
    backgroundImage: `url(${backgroundImage})`,
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    width: '100vw',
    height: '100vh'
    }}>
        {
            loginstate=="login"? (
              
    <div style={{marginLeft:"65%", paddingTop:"14%"}}>
    <Card style={{ width: '15rem',height:"18rem",borderRadius:"10px",backgroundColor:"#e0e0e0" }}>
        
          <Card.Body style={{}}>
            <Card.Title className="text-center mb-4">LOGIN</Card.Title>
            <Form>
          <Form.Group className="mb-4" controlId="formBasicEmail"  style={{width:205}}>
            <Form.Control type="text"  size="sm" placeholder= {ACCOUNT_ADDRESS} value={u_address}  onChange={(e)=>{
              setu_address(e.target.value)
          
            }}/>
          
          </Form.Group>

          <Form.Group className="mb-4" controlId="formBasicPassword"  style={{width:205}}>
            <Form.Control type="password"  size="sm" placeholder="Password" value={u_password} onChange={(e)=>{
              setu_password(e.target.value)}} />
          </Form.Group>

      
          <div className="d-grid px-5 mb-2">
          <Button variant="primary" size="sm" onClick={()=>{login_function(u_address,u_password) 
          }} >
          Login
          </Button>
          
        </div>
        <div style={{display:"flex" ,justifyContent:"center "}}>
        <Button variant="link" onClick={()=>{setloginstate("signup")
       setu_name("")
       setu_email("")
       setu_home_address("")
       setu_ph_no("")
       setu_password("")
       setu_address("")
       
      
        }
      
      } >Sign Up</Button>
        </div>
    
        </Form>
          
          </Card.Body>
        </Card>

       
    </div>
            ): loginstate=="signup"?
            (
                <div style={{marginLeft:"57%", paddingTop:"12%"}}>
                <Card style={{ width: '28rem',height:"20rem",borderRadius:"10px",backgroundColor:"#e0e0e0" } } >
                    
                      <Card.Body style={{}}>
                        <Card.Title className="text-center mb-4">SIGN UP</Card.Title>
                        <Form>
                          <Row>
                            <Col md={6}>
                            <Form.Group className="mb-4" controlId="formBasicEmail" style={{width:190}}>
                    
                    <Form.Control type="text" size="sm" placeholder=" Name" value={u_name}  onChange={(e)=>{
          setu_name(e.target.value)
      
        }}/>
                  
                  </Form.Group>
                            </Col>

                            <Col md={6}>
                            <Form.Group className="mb-4" controlId="formBasicEmail"  style={{width:190}}>
                    
                    <Form.Control type="text" size="sm" placeholder= {ACCOUNT_ADDRESS} value={u_address}  onChange={(e)=>{
          setu_address(e.target.value)
      
        }} />
                  
                  </Form.Group>
                            </Col>
                            </Row>
                     

                      <Row>
                        <Col md={6}>
                        <Form.Group className="mb-4" controlId="formBasicPassword" style={{width:190}}>
                    
                    <Form.Control type="password" size="sm" placeholder="Password" value={u_password} onChange={(e)=>{
          setu_password(e.target.value)
      
        }}/>
                  </Form.Group>
                        </Col>
                        <Col md={6}>
                        <Form.Group className="mb-4" controlId="formBasicPassword" style={{width:190}}>
                    
                    <Form.Control type="text" size="sm" placeholder="Contact number" value={u_ph_no} onChange={(e)=>{
          setu_ph_no(e.target.value)
      
        }}/>
                  </Form.Group>
                        </Col>
                      </Row>
                
                      

        <Row>
          <Col md={6}>
          <Form.Group className="mb-4" controlId="formBasicPassword" style={{width:190}}>
                    
                    <Form.Control type="text" size="sm"  placeholder="Email" value={u_email} onChange={(e)=>{
          setu_email(e.target.value)
      
        }}/>
                  </Form.Group>
          </Col>
          <Col md={6}>
          <Form.Group className="mb-1" controlId="formBasicPassword" style={{width:190}}>
                    
                    <Form.Control type="text" size="sm" placeholder="Address" value={u_home_address} onChange={(e)=>{
          setu_home_address(e.target.value)
      
        }}/>
                  </Form.Group>
          </Col>
        </Row>
    
       
                      <div className="d-grid px-4 mb-0 " style={{display:"flex",justifyContent:"center"}}>
                      <Button variant="primary" size="sm" style={{width:110}} onClick={()=>{
                        signup_function(u_address,u_name,u_password,u_ph_no,u_home_address,u_email)
                        setloading(true)
                        }}>
                      Sign up
                      </Button>
                      
                    </div>
                    <div style={{display:"flex" ,justifyContent:"center "}}>
                    <Button variant="link" onClick={()=>{setloginstate("login")
  setu_name("")
  setu_email("")
  setu_home_address("")
  setu_ph_no("")
  setu_password("")
  setu_address("")
     
        }} >Login</Button>
                    </div>
                
                    </Form>
                      
                      </Card.Body>
                    </Card>
                </div>
            ): loader==true?
            (
              <Spinner animation="border" variant="primary" />
            ):
            (
              null
            )
        }
      
    </div>

    </>

    );
    }
    export default Login;

